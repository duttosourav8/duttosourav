import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class ChosingSet extends JFrame implements ActionListener  {
    JLabel backgroundImg;
    JButton b1,b2,b3,b4,b5,b6;

public ChosingSet()
{
    super("Choose Set");
    this.setSize(800,700);
    setLocationRelativeTo(null);
setResizable(false);
setLayout(null);
setDefaultCloseOperation(EXIT_ON_CLOSE);

ImageIcon img = new ImageIcon(".\\Photos\\start.jpg");
        backgroundImg = new JLabel(img);
        backgroundImg.setBounds(0,0,800,700);

        Icon icon1 = new ImageIcon(".\\Photos\\seta.png");
		b3 = new JButton(icon1);
    b3.setBounds(10,50,120,25);
    b3.addActionListener(this);
    b3.setBorderPainted(false);
    b3.setFocusable(false);
    Icon icon2 = new ImageIcon(".\\Photos\\setb.png");
		b4 = new JButton(icon2);
    b4.setBounds(600,50,120,25);
    b4.addActionListener(this);
    b4.setBorderPainted(false);
    b4.setFocusable(false);
    Icon icon3 = new ImageIcon(".\\Photos\\setc.png");
		b5 = new JButton(icon3);
    b5.setBounds(10,500,120,25);
    b5.addActionListener(this);
    b5.setBorderPainted(false);
    b5.setFocusable(false);
    Icon icon4 = new ImageIcon(".\\Photos\\setd.png");
		b6 = new JButton(icon4);
    b6.setBounds(600,500,120,25);
    b6.addActionListener(this);
    b6.setBorderPainted(false);
    b6.setFocusable(false);

  
      
    Icon icon5 = new ImageIcon(".\\Photos\\back.png");
    b1 = new JButton(icon5);
    b1.setFont(new Font("Comic Sans MS",Font.BOLD,25));
    b1.setForeground(Color.white);
    b1.setBackground(new Color(26,7,56));
    b1.setBounds(10,620,80,30);
    b1.addActionListener(this);
    b1.setBorderPainted(false);
    b1.setFocusable(false);
    add(b1);
    
    backgroundImg.add(b3);
    backgroundImg.add(b4);
    backgroundImg.add(b5);
    backgroundImg.add(b6);
   add(backgroundImg);

    setVisible(true);
}
public void actionPerformed(ActionEvent ae)
{
    if(ae.getSource()==b1)
	{
		TimeDetails o = new TimeDetails();
		this.setVisible(false);
		o.setVisible(true);
	}
    else if(ae.getSource()==b2)
	{
        TimeDetails t = new TimeDetails();
		this.setVisible(false);
		t.setVisible(true);
    }
    else if(ae.getSource()==b3)
	{
        OnlineTest n = new OnlineTest("TEST YOURSELF");
		this.setVisible(false);
		n.setVisible(true);
    }
    else if(ae.getSource()==b4)
	{
        OnlineTest2 n1 = new OnlineTest2("TEST YOURSELF");
		this.setVisible(false);
		n1.setVisible(true);
    }
    else if(ae.getSource()==b5)
	{
        OnlineTest3 n2 = new OnlineTest3("TEST YOURSELF");
		this.setVisible(false);
		n2.setVisible(true);
    }
    else if(ae.getSource()==b6)
	{
        OnlineTest4 n3 = new OnlineTest4("TEST YOURSELF");
		this.setVisible(false);
		n3.setVisible(true);
    }
}
public static void main(String [] args)
{
    new ChosingSet();
}
}

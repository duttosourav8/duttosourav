import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.util.*;
import java.lang.*;
import java.io.*;
import java.nio.file.*;

public class Login extends JFrame {

 JLabel l1, l2, l3, backgroundImg;
 JTextField t1;
 JButton b1, b2;
  JPasswordField t2;

    Login() {
        // Frame Layout
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setTitle("TEST YOURSELF");
        this.setSize(570, 410);
        this.setLocationRelativeTo(null);
        this.setResizable(false);
        this.setLayout(null);


        
		ImageIcon img = new ImageIcon(".\\Photos\\Login.jpg");
        backgroundImg = new JLabel(img);
        backgroundImg.setSize(new Dimension(570,400));
        this.add(backgroundImg);
     
        

        l1 = new JLabel("Student Login");
        l1.setBounds(100, 20, 500, 50);
        l1.setFont(new Font("Segoe UI Black", Font.BOLD, 40));
        backgroundImg.add(l1);


        l2 = new JLabel("UserName");
        l2.setBounds(220, 130, 200, 30);
        l2.setForeground(new Color(239,255,165));
        l2.setFont(new Font("Segoe UI Black", Font.BOLD, 30));
        backgroundImg.add(l2);

        t1 = new JTextField();
        t1.setBounds(400, 130, 120, 35);
        backgroundImg.add(t1);


        l3 = new JLabel("Password");
        l3.setBounds(220, 200, 200, 30);
        l3.setForeground(new Color(239,255,165));
        l3.setFont(new Font("Segoe UI Black", Font.BOLD, 30));
        backgroundImg.add(l3);

        t2 = new JPasswordField();
        t2.setBounds(400, 200, 120, 35);
        backgroundImg.add(t2);



        Icon icon1 = new ImageIcon(".\\Photos\\return.png");
		b1 = new JButton(icon1);
        b1.setBounds(30, 330, 40, 40);
        b1.setBorderPainted(false);
        b1.setFocusable(false);
        backgroundImg.add(b1);

        Icon icon2 = new ImageIcon(".\\Photos\\loginbtn.png");
		b2 = new JButton(icon2);
        b2.setBounds(350, 300, 180, 40);
        b2.setBorderPainted(false);
        b2.setFocusable(false);
        b2.setForeground(Color.WHITE);
        b2.setBackground(Color.decode("#2E75B6"));
        backgroundImg.add(b2);

setVisible(true);
        b1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {

                setVisible(false);
                Options frame = new Options();
                frame.setVisible(true);
            }
        });


        // Login Button
        b2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {

                String textField1 = t1.getText().toLowerCase(); // User Name 
                String textField2 = t2.getText(); // Password

                if (textField1.isEmpty() || textField2.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Please fill all of the fields.", "Warning!",
                            JOptionPane.WARNING_MESSAGE);
                } else {

                    try {
                        String userNameS = "User Name : " + textField1;
                        String passwordS = "Password : " + textField2;
                        BufferedReader reader = new BufferedReader(new FileReader(".\\Files\\login.txt"));

                        int totalLines = 0;
                        while (reader.readLine() != null)
                            totalLines++;
                        reader.close();

                        for (int i = 0; i <= totalLines; i++) {
                            String line = Files.readAllLines(Paths.get(".\\Files\\login.txt")).get(i);
                            if (line.equals(userNameS)) {
                                String line2 = Files.readAllLines(Paths.get(".\\Files\\login.txt")).get((i + 1));
                                if (line2.equals(passwordS)) {
                                    JOptionPane.showMessageDialog(null, "Login Successful");

                                    setVisible(false);
                                    TimeDetails frame = new TimeDetails();
                                    frame.setVisible(true);
                                    break;
                                }
                            }
                        }
                    } catch (Exception ex) {
                        JOptionPane.showMessageDialog(null, "Invalid User Name or Password!", "Warning!",
                                JOptionPane.WARNING_MESSAGE);
                    }

                }

            }
        });
    }

    public static void main(String[] args) {

        Login frame = new Login();
        frame.setVisible(true);
    }
}

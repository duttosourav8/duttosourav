import javax.swing.ImageIcon;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class ImageExample extends JFrame implements ActionListener
{	   
	   JLabel jl,l1;
	   JPanel p1;
	   JButton b1,b2;

	public ImageExample()
	{

super("TEST YOURSELF");
this.setSize(1000,800);
setLocationRelativeTo(null);
setResizable(false);
setDefaultCloseOperation(EXIT_ON_CLOSE);

p1=new JPanel();
p1.setSize(new Dimension(1000,800));
p1.setBackground(Color.WHITE);
p1.setLayout(null);


jl = new JLabel();
jl.setIcon(new ImageIcon(".\\Photos\\Front.jpg"));
jl.setBounds(200,0,1000,800);
p1.add(jl);


l1 = new JLabel("WELCOME");
l1.setFont(new Font("Castellar",Font.BOLD,50));
l1.setForeground(new Color(171,39,93));
l1.setBounds(350, 50, 300, 50);
p1.add(l1);


ImageIcon Exit = new ImageIcon(".\\Photos\\Exit.png");
b1 = new JButton(Exit);
b1.setBounds(0, 700, 100, 60);
b1.setBorderPainted(false);
b1.setFocusable(false);
b1.addActionListener(this);
p1.add(b1);

ImageIcon enter = new ImageIcon(".\\Photos\\Enter.png");

b2 = new JButton(enter);
b2.setBounds(780, 700, 200, 150);
b2.setBorderPainted(false);
b2.setFocusable(false);
b2.addActionListener(this);
p1.add(b2);


this.add(p1);

validate();
setVisible(true);

}

public void actionPerformed(ActionEvent ae)
{
	if(ae.getSource()==b1)
	{
		this.dispose();
	}
    else if(ae.getSource()==b2)
	{
		Options o = new Options();
		this.setVisible(false);
		o.setVisible(true);
	}

}
public static void main(String [] args)
{

new ImageExample();

}

}
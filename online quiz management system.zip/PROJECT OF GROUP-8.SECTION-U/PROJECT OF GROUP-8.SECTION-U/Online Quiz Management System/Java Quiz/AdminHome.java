import java.lang.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class AdminHome extends JFrame implements ActionListener
{
		
			JLabel jl = new JLabel();
			JLabel backgroundImg,l1,l2,l3,l4,l5;
		JTextField t1,t2;
		JButton b1,b2,b3,b4,b5,b6,b7; 
		JPanel p1,p2,p3,p4;
		
	public AdminHome()
	{
			
		super("Admin Home");
		this.setSize(1022,550);
		this.setBackground(Color.WHITE);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
        setResizable(false);
		setLayout(null);
		
		
		ImageIcon img = new ImageIcon(".\\Photos\\Home.jpg");
        backgroundImg = new JLabel(img);
        backgroundImg.setBounds(0,0,1022,502);
      
		
		Icon icon4 = new ImageIcon(".\\Photos\\result.png");
        b4 = new JButton(icon4);
		b4.setBounds(10, 20, 130, 100);
		b4.setBorderPainted(false);
        b4.setFocusable(false);
		b4.addActionListener(this);
		backgroundImg.add(b4);
		

		
Icon icon3 = new ImageIcon(".\\Photos\\info.png");
b5 = new JButton(icon3);
b5.setBounds(750, 20, 180, 60);
b5.addActionListener(this);
b5.setBorderPainted(false);
b5.setFocusable(false);
backgroundImg.add(b5);

Icon icon1 = new ImageIcon(".\\Photos\\Logout.png");
b6 = new JButton(icon1);
b6.setBounds(780, 440, 210, 60);
b6.setBorderPainted(false);
b6.setFocusable(false);
b6.addActionListener(this);
backgroundImg.add(b6);

Icon icon2 = new ImageIcon(".\\Photos\\Exit.png");
b7 = new JButton(icon2);
b7.setBounds(10, 440, 80, 60);
b7.addActionListener(this);
b7.setBorderPainted(false);
b7.setFocusable(false);
backgroundImg.add(b7);

this.add(backgroundImg);
validate();
setVisible(true);


	}	
	public void actionPerformed(ActionEvent ae)
{
	
	if(ae.getSource()==b5)
	{
		AllStudent n= new AllStudent();
	this.setVisible(false);
	n.setVisible(true);
	}
	
    else if(ae.getSource()==b6)
	{
    adminLogin a= new adminLogin();
	this.setVisible(false);
	a.setVisible(true);
	
    }
	else if(ae.getSource()==b4)
	{
    AllStudentResult r= new AllStudentResult();
	this.setVisible(false);
	r.setVisible(true);
	
    }
	else if(ae.getSource()==b7)
	{
	
    Options o = new Options();
	this.setVisible(false);
	o.setVisible(true);
	
	
    }


}	
		
	public static void main(String [] args)
	{
	new AdminHome();
	//new SignUp();

	}
	
}
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.table.*;
import java.util.*;
import java.io.*;
import java.nio.file.*;
import java.lang.*;

public class AllStudent extends JFrame {



    private JLabel backgroundImg;
    private JScrollPane scroll;
    private JTable table;
    private DefaultTableModel model;
    private JButton  btn4, btn5;
    private Cursor cursor;

    private String[] column = { "User Name", "Password", "InstitutionID", "Security Question", "Answer", "Date and Time" };
    private String[] rows = new String[7];

    AllStudent() {
    
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setTitle("Student Registration Info");
        this.setSize(700, 600);
        this.setLocationRelativeTo(null);
        this.setResizable(false);
        this.setLayout(null);
       
        ImageIcon img = new ImageIcon(".\\Photos\\Student.png");
        backgroundImg = new JLabel(img);
        backgroundImg.setBounds(0,0,700,600);
        add(backgroundImg);
        
       

        cursor = new Cursor(Cursor.HAND_CURSOR);
        Icon icon1 = new ImageIcon(".\\Photos\\Exit.png");
	    btn4 = new JButton(icon1);
        btn4.setBounds(10, 500, 100, 50);
        btn4.setCursor(cursor);
        backgroundImg.add(btn4);
      
        Icon icon2 = new ImageIcon(".\\Photos\\back.png");
        btn5 = new JButton(icon2);
        btn5.setBounds(600, 500, 80, 50);
        btn5.setCursor(cursor);
        backgroundImg.add(btn5);



       // Exit Button
       btn4.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent ae) {
            System.exit(0);
        }
    });

    // Back Button
    btn5.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent ae) {
            setVisible(false);
            AdminHome frame = new AdminHome();
            frame.setVisible(true);
        }
    });

        // JTable Layout
        table = new JTable();
        model = new DefaultTableModel();
        model.setColumnIdentifiers(column);

        table.setModel(model);
        table.setSelectionBackground(Color.decode("#8AC5FF"));
        table.setBackground(Color.WHITE);
        table.setRowHeight(30);
        table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        table.getColumnModel().getColumn(0).setPreferredWidth(120);
        table.getColumnModel().getColumn(1).setPreferredWidth(120);
        table.getColumnModel().getColumn(2).setPreferredWidth(200);
        table.getColumnModel().getColumn(3).setPreferredWidth(220);
        table.getColumnModel().getColumn(4).setPreferredWidth(200);
        table.getColumnModel().getColumn(5).setPreferredWidth(220);

        scroll = new JScrollPane(table);
        scroll.setBounds(53, 96, 578, 300);
        scroll.setBackground(Color.WHITE);
        backgroundImg.add(scroll);

        String file = ".\\Files\\login.txt";


        // To input data in the table
        try {

            BufferedReader reader = new BufferedReader(new FileReader(file));
            int totalLines = 0;
            while (reader.readLine() != null)
                totalLines++;
            reader.close();

            for (int i = 0; i < totalLines; i++) {
                String line = Files.readAllLines(Paths.get(file)).get(i);
                String x = line.substring(0, 4);
                if (x.equals("User")) {
                    rows[0] = Files.readAllLines(Paths.get(file)).get(i).substring(12); // User Name
                    rows[1] = Files.readAllLines(Paths.get(file)).get((i + 1)).substring(11); // Password
                    rows[2] = Files.readAllLines(Paths.get(file)).get((i + 2)).substring(0); // Email
                    rows[3] = Files.readAllLines(Paths.get(file)).get((i + 3)).substring(20); // Security Question
                    rows[4] = Files.readAllLines(Paths.get(file)).get((i + 4)).substring(9); // Answer
                    rows[5] = Files.readAllLines(Paths.get(file)).get((i + 5)).substring(14); // Date and Time
                    model.addRow(rows);
                }
            }

        } catch (Exception ex) {
            return;
        }

    
       
    }


    public static void main(String[] args) {

        AllStudent frame = new AllStudent();
        frame.setVisible(true);
    }
}

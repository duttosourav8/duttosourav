import java.lang.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;

class OnlineTest extends JFrame implements ActionListener {
	
	private static final long serialVersionUID = 1L;

	JLabel backgroundImg,label,l1,l2;
	JRadioButton radioButton[] = new JRadioButton[5];
	JButton btnNext, btnBookmark;
	ButtonGroup bg;
	JTextField t1,t2;
	int count = 0, current = 0, x = 1, y = 1, now = 0;
	int m[] = new int[10];

	// create jFrame with radioButton and JButton
	OnlineTest(String s) {
		super(s);
		ImageIcon img = new ImageIcon(".\\Photos\\Quiz.jpg");
        backgroundImg = new JLabel(img);
        backgroundImg.setBounds(0,0,700,400);
		
		label = new JLabel();
		label.setForeground(Color.WHITE);
		t1=new JTextField();  
		t1.setBounds(450,30,100,20); 
		l1=new JLabel("Exam: Set A");  
		l1.setBounds(80,30,100,20);
		l1.setForeground(Color.WHITE);
		backgroundImg.add(t1);backgroundImg.add(l1);
		backgroundImg.add(label);
		t2=new JTextField();  
		t2.setBounds(300,30,100,20); 
		l2=new JLabel("Student Name:");  
		l2.setBounds(200,30,100,20);
		l2.setForeground(Color.WHITE);
		backgroundImg.add(t2);backgroundImg.add(l2);
		bg = new ButtonGroup();
		for (int i = 0; i < 5; i++) {
			radioButton[i] = new JRadioButton();
			backgroundImg.add(radioButton[i]);
			bg.add(radioButton[i]);
		}
		Icon icon1 = new ImageIcon(".\\Photos\\Next.png");
		btnNext = new JButton(icon1);

		btnBookmark = new JButton("Bookmark");
		btnNext.addActionListener(this);
		btnBookmark.addActionListener(this);
		backgroundImg.add(btnNext);
		backgroundImg.add(btnBookmark);
		set();
		label.setBounds(150, 130, 450, 20);
        radioButton[0].setBounds(230, 170, 150, 20);
		radioButton[1].setBounds(230, 210, 150, 20);
		radioButton[2].setBounds(230, 250, 150, 20);
		radioButton[3].setBounds(230, 290, 150, 20);
		radioButton[0].setBackground(Color.BLACK);
		radioButton[0].setForeground(Color.WHITE);
		radioButton[1].setBackground(Color.BLACK);
		radioButton[1].setForeground(Color.WHITE);
        radioButton[2].setBackground(Color.BLACK);
		radioButton[2].setForeground(Color.WHITE);
		radioButton[3].setBackground(Color.BLACK);
		radioButton[3].setForeground(Color.WHITE);
		btnNext.setBounds(100, 330, 80, 30);
		btnBookmark.setBounds(495, 330, 127, 30);
		btnBookmark.setBackground(new Color(239,228,176));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLayout(null);
		setLocation(250, 100);
		setVisible(true);
		this.setSize(700, 400);
		setLocationRelativeTo(null);
        setResizable(false);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 	
		add(backgroundImg);
	}

	// handle all actions based on event
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == btnNext) {
			String userName=t2.getText();
			if(userName.isEmpty()){
				JOptionPane.showMessageDialog(this, "Write Your Username");
				dispose();
				OnlineTest a = new OnlineTest("TEST YOURSELF");
				a.setVisible(true);

			}
			else if (check())
				count = count + 1;
			current++;
			set();
			if (current == 9) {
				btnNext.setEnabled(false);
				btnBookmark.setText("Result");
			}
		}
		if (e.getActionCommand().equals("Bookmark")) {
			
			JButton bk = new JButton("Bookmark"+x);
			bk.setBounds(580, 10 + 20 * x, 100, 30);
			backgroundImg.add(bk);
			bk.setBackground(new Color(239,228,176));
			bk.addActionListener(this);
			m[x] = current;
			x++;
			current++;
			set();
			if (current == 9)
				btnBookmark.setText("Result");
			setVisible(false);
			setVisible(true);
		}
		for (int i = 0, y = 1; i < x; i++, y++) {
			if (e.getActionCommand().equals("Bookmark" + y)) {
				if (check())
					count = count + 1;
				now = current;
				current = m[y];
				set();
				((JButton) e.getSource()).setEnabled(false);
				current = now;
			}
		}

		if (e.getActionCommand().equals("Result")) {
			if (check())
				count = count + 1;
			current++;
			t1.setText("Marks="+count);
			JOptionPane.showMessageDialog(this, "correct answers= " + count);
		    try{
				FileWriter fw = new FileWriter(".\\Files\\result.txt",true);
				fw.write(l2.getText());
				fw.write(t2.getText()+"\n");
				fw.write(l1.getText()+"\n");
				fw.write(t1.getText()+"\n");
				
				fw.close();
			  } 
			  catch(Exception ae){}
		dispose();
			Contribution t= new Contribution();
			t.setVisible(true);
		}
	}
	
	// SET Questions with options
	void set() {
		radioButton[4].setSelected(true);
		if (current == 0) {
			label.setText("Question-1:  Which of the following is not introduced with Java 8?");
			radioButton[0].setText("Stream API");
			radioButton[1].setText("Serialization");
			radioButton[2].setText("Spliterator");
			radioButton[3].setText("Lambda Expression");
		}
		if (current == 1) {
			label.setText("Question-2:  Which feature of java 7 allows to not explicitly close IO resource?");
			radioButton[0].setText("try catch finally");
			radioButton[1].setText("IOException");
			radioButton[2].setText("AutoCloseable");
			radioButton[3].setText("Streams");
		}
		if (current == 2) {
			label.setText("Question-3: SessionFactory is a thread-safe object.");
			radioButton[0].setText("true");
			radioButton[1].setText("false");
			radioButton[2].setText("don't know");
			radioButton[3].setText("false");
		}
		if (current == 3) {
			label.setText("Question-4: Which is the new method introduced in java 8 to iterate over a collection?");
			radioButton[0].setText("for (String i : StringList)");
			radioButton[1].setText("foreach (String i : StringList)");
			radioButton[2].setText("StringList.forEach()");
			radioButton[3].setText("List.for()");
		}
		if (current == 4) {
			label.setText("Question-5:  What is the substitute of Rhino javascript engine in Java 8?");
			radioButton[0].setText(" Nashorn");
			radioButton[1].setText("V8");
			radioButton[2].setText("Inscript");
			radioButton[3].setText("Narcissus");
		}
		if (current == 5) {
			label.setText("Question-6: How to read entire file in one line using java 8?");
			radioButton[0].setText("Files.readAllLines()");
			radioButton[1].setText("Files.read()");
			radioButton[2].setText("Files.readFile()");
			radioButton[3].setText("Files.lines()");
		}
		if (current == 6) {
			label.setText("Question7:  Which feature of java 7 allows to not explicitly close IO resource?");
			radioButton[0].setText("try catch finally");
			radioButton[1].setText("IOException");
			radioButton[2].setText("AutoCloseable");
			radioButton[3].setText("Streams");
		}
		if (current == 7) {
			label.setText("Question-8:  Which of the following is not a core interface of Hibernate?");
			radioButton[0].setText("Configuration");
			radioButton[1].setText("Criteria");
			radioButton[2].setText("SessionManagement");
			radioButton[3].setText("Session");
		}
		if (current == 8) {
			label.setText("Question-9: SessionFactory is a thread-safe object.");
			radioButton[0].setText("true");
			radioButton[1].setText("false");
			radioButton[2].setText("don't know");
			radioButton[3].setText("false");
		}
		if (current == 9) {
			label.setText("Question-10: Which of the following is not a state of object in Hibernate?");
			radioButton[0].setText("Attached()");
			radioButton[1].setText("Detached()");
			radioButton[2].setText("Persistent()");
			radioButton[3].setText("Transient()");
		}
		label.setBounds(150, 130, 450, 20);
	}

	// declare right answers.
	boolean check() {
		if (current == 0)
			return (radioButton[1].isSelected());
		if (current == 1)
			return (radioButton[1].isSelected());
		if (current == 2)
			return (radioButton[0].isSelected());
		if (current == 3)
			return (radioButton[2].isSelected());
		if (current == 4)
			return (radioButton[0].isSelected());
		if (current == 5)
			return (radioButton[0].isSelected());
		if (current == 6)
			return (radioButton[1].isSelected());
		if (current == 7)
			return (radioButton[2].isSelected());
		if (current == 8)
			return (radioButton[0].isSelected());
		if (current == 9)			return (radioButton[0].isSelected());
		return false;
	}
	

	public static void main(String s [] ) {
		new OnlineTest("TEST YOURSELF");
	}

}
import java.lang.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Options extends JFrame implements ActionListener
{
	    
		JButton b1,b2,b3,b4; 
		JPanel p1;
		JLabel l1, backgroundImg;
		
	public Options()
	{
		super("TEST YOURSELF");
		this.setSize(700,550);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
        setResizable(false);
		
	
		ImageIcon img = new ImageIcon(".\\Photos\\Options.jpg");
        backgroundImg = new JLabel(img);
        backgroundImg.setBounds(0,0,800,600);
      
		l1 = new JLabel("What Do You Want?");
        l1.setFont(new Font("Times New Roman",Font.ITALIC,30));
        l1.setForeground(new Color(171,39,93));
        l1.setBounds(50, 200, 300, 25);
        backgroundImg.add(l1);
		
		Icon icon1 = new ImageIcon(".\\Photos\\studentlogin.png");
		b1 = new JButton(icon1);
		b1.setFont(new Font("Comic Sans MS",Font.BOLD,25));
		b1.setForeground(Color.white);
		b1.setBackground(Color.WHITE);
		b1.setBounds(50,250,150,150);
		b1.addActionListener(this);
		b1.setBorderPainted(false);
        b1.setFocusable(false);
		backgroundImg.add(b1);
		
		Icon icon4 = new ImageIcon(".\\Photos\\register.png");
		b2 = new JButton(icon4);
		b2.setFont(new Font("Comic Sans MS",Font.BOLD,25));
		b2.setForeground(Color.white);
		b2.setBackground(Color.white);
		b2.setBounds(250, 250, 150, 150);
		b2.setBorderPainted(false);
        b2.setFocusable(false);
		b2.addActionListener(this);
		backgroundImg.add(b2);
		
		Icon icon = new ImageIcon(".\\Photos\\logo.png");
	    b3 = new JButton(icon);
		b3.setFont(new Font("Comic Sans MS",Font.BOLD,25));
		b3.setForeground(Color.white);
		b3.setBackground(Color.WHITE);
		b3.setBounds(470, 250, 100, 150);
		b3.addActionListener(this);
		b3.setBorderPainted(false);
        b3.setFocusable(false);
		backgroundImg.add(b3);
		
		Icon icon3 = new ImageIcon(".\\Photos\\back.png");
	    b4 = new JButton(icon3);
		b4.setFont(new Font("Comic Sans MS",Font.BOLD,25));
		b4.setForeground(Color.white);
		b4.setBackground(Color.white);
		b4.setBounds(10, 450, 100, 50);
		b4.setBorderPainted(false);
        b4.setFocusable(false);
		b4.addActionListener(this);
		backgroundImg.add(b4);
		
		this.add(backgroundImg);
		setVisible(true);
	
	}
	public void actionPerformed(ActionEvent ae)
{
	if(ae.getSource()==b1)
	{
		Login l= new Login();
		this.setVisible(false);
	l.setVisible(true);
	}
    else if(ae.getSource()==b2)
	{
	Registration r= new Registration();
	this.setVisible(false);
	r.setVisible(true);
	
    }
	else if(ae.getSource()==b3)
	{
	
		JOptionPane.showMessageDialog(this,"Username: admin, Password:12345."); 
			adminLogin a = new adminLogin();
			this.setVisible(false);
	        a.setVisible(true);
	
    }
	else if(ae.getSource()==b4)
	{
		ImageExample i= new ImageExample();
	this.setVisible(false);
	i.setVisible(true);
	
    }

}
	public static void main(String [] args)
	{
	new Options();
	//new SignUp();

	}
	
	
}
import javax.swing.*;
import java.io.FileReader;
import java.awt.event.ActionEvent;
import java.io.BufferedReader;
import java.awt.*;
import java.awt.event.*;

public class AllStudentResult extends JFrame implements ActionListener {
    JLabel backgroundImg,exitgroundImg;
    JTextArea jTextArea;
    private JButton backBtn,btn4;
    public AllStudentResult()
    {
        super("Student Result Info");
        this.setSize(816,615);
        this.setLayout(null);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        
        ImageIcon img = new ImageIcon(".\\Photos\\photo.jpeg");
        backgroundImg = new JLabel("", img,JLabel.CENTER);
        backgroundImg.setBounds(0,0,800,576);

        ImageIcon backBtnButtonImg = new ImageIcon(".\\Photos\\back.png");

        backBtn = new JButton(backBtnButtonImg);
        backBtn.setBounds(80,520,80,50);
        backBtn.setBorderPainted(false);
        backBtn.setFocusable(false);

        ImageIcon exitBtnButtonImg = new ImageIcon(".\\Photos\\Exit.png");
        btn4 = new JButton(exitBtnButtonImg);
        btn4.setBounds(620, 500, 150, 60);
        btn4.setBorderPainted(false);
        btn4.setFocusable(false);



        
        backBtn.addActionListener(this);
        backgroundImg.add(backBtn);

        btn4.addActionListener(this);
        backgroundImg.add(btn4);
        btn4.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                System.exit(0);
            }
        });

        jTextArea = new JTextArea();
        jTextArea.setBounds(40,40,720,450);
        this.add(backgroundImg);

        try{
            BufferedReader br=null;
            FileReader fr=null;
            fr=new FileReader(".\\Files\\result.txt");
            br = new BufferedReader(fr);
            String a="",temp;
            while((temp=br.readLine())!=null) {
              a=a+temp+"\n"+"\r";
              jTextArea.setText(a);
              jTextArea.setLineWrap(true);
            }
		    }  
        catch(Exception e)
        {
          e.printStackTrace();
        }
		
        backgroundImg.add(jTextArea);

        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae)
    {
        if(ae.getSource()==backBtn)
        {
            this.setVisible(false);
            AdminHome h = new AdminHome();
            h.setVisible(true);
        }
    }
    

public static void main(String [] args)
{
    new AllStudentResult();
}
}
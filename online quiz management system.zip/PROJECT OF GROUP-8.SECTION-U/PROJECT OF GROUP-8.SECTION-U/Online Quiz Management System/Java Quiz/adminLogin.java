import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class adminLogin extends JFrame implements ActionListener 
{

    JPanel p;
    JLabel userLabel = new JLabel("ID");
    JLabel passwordLabel = new JLabel("Security Code");
    JTextField userTextField = new JTextField();
    JPasswordField passwordField = new JPasswordField();
    JButton loginButton = new JButton("LOGIN");
    JButton resetButton = new JButton("RESET");
    JButton backButton = new JButton("BACK");
    JCheckBox showPassword = new JCheckBox("Show Password");
    JLabel backgroundImg;


    public adminLogin() {
	    super("Admin Login");
        this.setSize(600, 650);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setResizable(false);
		setLocationRelativeTo(null);
        setLayout(null);
    
        ImageIcon img = new ImageIcon(".\\Photos\\admin.png");
        backgroundImg = new JLabel(img);
        backgroundImg.setBounds(0,0,600,600);
        add(backgroundImg);
      

        userLabel = new JLabel("UserName");
        passwordLabel = new JLabel("Password");
        userTextField = new JTextField();
        passwordField = new JPasswordField();
        loginButton = new JButton("LOGIN");
        resetButton = new JButton("RESET");
        backButton = new JButton("BACK");
        showPassword = new JCheckBox("Show Password");

        userLabel.setBounds(450, 130, 100, 30);
        passwordLabel.setBounds(450, 200, 100, 30);
        userTextField.setBounds(410, 160, 130, 30);
        passwordField.setBounds(410, 240, 130, 30);
        showPassword.setBounds(410, 270, 150, 30);
        showPassword.setBackground(new Color(210,255,211));
        loginButton.setBounds(470, 310, 80, 30);
        loginButton.setBackground(new Color(210,255,211));
        resetButton.setBounds(470, 350, 80, 30);
        backButton.setBounds(410, 380, 100, 30);
        resetButton.setBackground(new Color(210,255,211));
        backButton.setBackground(new Color(210,255,211));

        showPassword.setBorderPainted(false);
        showPassword.setFocusable(false);     
      

        backgroundImg.add(userLabel);
        backgroundImg.add(passwordLabel);
        backgroundImg.add(userTextField);
        backgroundImg.add(passwordField);
        backgroundImg.add(showPassword);
        backgroundImg.add(loginButton);
        backgroundImg.add(resetButton);
        backgroundImg.add(backButton);



        loginButton.addActionListener(this);
        resetButton.addActionListener(this);
        backButton.addActionListener(this);
        showPassword.addActionListener(this);

        validate();
        setVisible(true);}

    @Override
    public void actionPerformed(ActionEvent e) {
        //Coding Part of LOGIN button
        if (e.getSource() == loginButton) 
        {
            String userText;
            String pwdText;
            userText = userTextField.getText();
            pwdText = passwordField.getText();
            if (userText.equalsIgnoreCase("admin") && pwdText.equalsIgnoreCase("12345")) {
                JOptionPane.showMessageDialog(this, "Admin Entered");
                AdminHome h = new AdminHome();
                this.setVisible(false);
                h.setVisible(true);
            } else {
                JOptionPane.showMessageDialog(this, "Invalid Name or Password");   
            }
        }
        //Coding Part of RESET button
        else if (e.getSource() == resetButton) {
            userTextField.setText("");
            passwordField.setText("");
        }
       //Coding Part of showPassword JCheckBox
        else if (e.getSource() == showPassword) {
            if (showPassword.isSelected()) {
                passwordField.setEchoChar((char) 0);
            } else {
                passwordField.setEchoChar('*');
            } }
            else if (e.getSource() == backButton) {
               Options h= new Options();
               this.setVisible(false);
               h.setVisible(true);
            }}




    public static void main(String[] args)
     {
        new adminLogin();
    }

}
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class Contribution extends JFrame {

    
    private JLabel backgroundImg;
    private JButton btn1;
    private Cursor cursor;

    Contribution() {
        
        this.setTitle("TEST YOURSELF");
        this.setSize(540, 700);
        this.setLocationRelativeTo(null);
        this.setResizable(false);
        this.setLayout(null);

        ImageIcon img = new ImageIcon(".\\Photos\\oop.png");
        backgroundImg = new JLabel(img);
        backgroundImg.setSize(new Dimension(540,700));
        this.add(backgroundImg);
     

        
        cursor = new Cursor(Cursor.HAND_CURSOR);

        
        btn1 = new JButton("OK");
        btn1.setBounds(450, 600, 80, 50);
        btn1.setCursor(cursor);
        btn1.setForeground(Color.black);
        btn1.setBackground(Color.white);
        backgroundImg.add(btn1);



        btn1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
               setVisible(false);
               Login l = new Login();
               l.setVisible(true);
            }
        });
    
       setVisible(true);
    }

    public static void main(String[] args) {

        Contribution frame = new Contribution();
        frame.setVisible(true);
    }
}

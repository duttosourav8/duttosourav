import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.util.*;
import java.lang.*;
import java.io.*;
import java.nio.file.*;
import java.time.*;
import java.time.format.*;

public class Registration extends JFrame {


 JLabel backgroundImg,label1;
JTextField tf1, tf2, tf4, tf5,tf6,tf7;
 JComboBox securityQsn;
JButton btn1, btn2, btn3, btn4, nBtn;
 JPasswordField tf3;
Cursor cursor;
private int a, b;

    Registration() {
        // Frame Layout
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setTitle("TEST YOURSELF");
        this.setSize(800, 700);
        this.setLocationRelativeTo(null);
        this.setLayout(null);
        this.setResizable(false);


        ImageIcon img = new ImageIcon(".\\Photos\\Regform.png");
        backgroundImg = new JLabel(img);
        backgroundImg.setBounds(0,0,800,700);
        add(backgroundImg);


        label1 = new JLabel("Enter Your Information");
        label1.setFont(new Font("Times New Roman", Font.BOLD, 30));
        label1.setBounds(40, 20, 500, 50);
        backgroundImg.add(label1);


        label1 = new JLabel("User Name");
        label1.setFont(new Font("Times New Roman", Font.BOLD, 20));
        label1.setBounds(40, 80, 500, 50);
        backgroundImg.add(label1);

        tf1 = new JTextField();
        tf1.setBounds(140, 90, 260, 30);
        backgroundImg.add(tf1);


        label1 = new JLabel("Institution ID");
        label1.setBounds(10, 130, 500, 50);
        label1.setFont(new Font("Times New Roman", Font.BOLD, 20));
        backgroundImg.add(label1);

        tf2 = new JTextField();
        tf2.setBounds(140, 140, 260, 30);
        backgroundImg.add(tf2);


        label1 = new JLabel("Password");
        label1.setBounds(40, 180, 500, 50);
        label1.setFont(new Font("Times New Roman", Font.BOLD, 20));
        backgroundImg.add(label1);

        tf3 = new JPasswordField();
        tf3.setBounds(140, 190, 260, 30);
        backgroundImg.add(tf3);

        label1 = new JLabel("Question");
        label1.setBounds(40, 230, 500, 50);
        label1.setFont(new Font("Times New Roman", Font.BOLD, 20));
        backgroundImg.add(label1);

        String[] secQsn = { "Choose a Security Question", "Your Future Dream?", "Your Favorite Subject?",
        "Your Favorite Hobby?" ,"Your Favorite Personality?" };
        securityQsn = new JComboBox(secQsn);
        securityQsn.setBounds(140, 240, 259, 30);
        securityQsn.setSelectedIndex(0);
        securityQsn.setBackground(Color.white);
        backgroundImg.add(securityQsn);

        // Answer
        label1 = new JLabel("Answer");
        label1.setBounds(40, 280, 500, 50);
        label1.setFont(new Font("Times New Roman", Font.BOLD, 20));
        backgroundImg.add(label1);

        tf4 = new JTextField();
        tf4.setBounds(140, 290, 260, 30);
        backgroundImg.add(tf4);

       

        label1 = new JLabel("Captcha");
        label1.setBounds(20, 330, 500, 50);
        label1.setFont(new Font("Times New Roman", Font.BOLD, 20));
        backgroundImg.add(label1);

        tf5 = new JTextField();
        tf5.setBounds(180, 340, 220, 30);
        backgroundImg.add(tf5);

        // To get a random number for captcha
        Random rand = new Random();
        int a = rand.nextInt(10);
        int b = rand.nextInt(10);

        // Captcha
        label1 = new JLabel();
        label1.setText(" " + a + " + " + b + " ");
        label1.setBounds(100, 340, 75, 30);
        label1.setForeground(Color.YELLOW);
        label1.setBackground(Color.BLACK);
        label1.setOpaque(true);
        backgroundImg.add(label1);


        // Cursor for JButtons
        cursor = new Cursor(Cursor.HAND_CURSOR);

        Icon icon1 = new ImageIcon(".\\Photos\\back.png");
	    btn2 = new JButton(icon1);
        btn2.setBorderPainted(false);
        btn2.setFocusable(false);
        btn2.setBounds(20, 600, 80, 50);
        btn2.setCursor(cursor);
        backgroundImg.add(btn2);

        

        // Back Button
        btn2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {

                setVisible(false);
                Options frame = new Options();
                frame.setVisible(true);
            }
        });

        Icon icon2 = new ImageIcon(".\\Photos\\reset.png");
	    btn3 = new JButton(icon2);
        btn3.setBounds(20, 400, 100, 50);
        btn3.setBorderPainted(false);
        btn3.setBackground(Color.white);
        btn3.setFocusable(false);
        btn3.setCursor(cursor);
        backgroundImg.add(btn3);

               // Reset Button
               btn3.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent ae) {
    
                    setVisible(false);
                    Registration frame = new Registration();
                    frame.setVisible(true);
                }
            });

        Icon icon3 = new ImageIcon(".\\Photos\\registerbtn.png");
	    btn4 = new JButton(icon3);
        btn4.setBounds(320, 400, 80, 50);
        btn4.setBorderPainted(false);
        btn4.setFocusable(false);
        btn4.setCursor(cursor);
        backgroundImg.add(btn4);


        // Register Button
        btn4.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {

                String textField1 = tf1.getText().toLowerCase(); // User Name
                String textField2 = tf2.getText(); // Inst ID
                String textField3 = tf3.getText(); // Password
                String textField4 = tf4.getText(); // Security Question Answer
                String textField5 = tf5.getText(); // Captcha
                String secQsn = String.valueOf(securityQsn.getSelectedItem()); // Security Question
                int result = 0;

                if (textField5.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Please fill all of the fields.", "Warning!",
                            JOptionPane.WARNING_MESSAGE);
                } else {
                    result = Integer.parseInt(tf5.getText());
                    if (textField1.isEmpty() || textField2.isEmpty() || textField3.isEmpty() || textField4.isEmpty()
                            || textField5.isEmpty() || ((securityQsn.getSelectedIndex()) == 0)) {
                        JOptionPane.showMessageDialog(null, "Please fill all of the fields.", "Warning!",
                                JOptionPane.WARNING_MESSAGE);
                    } else if (result != (a + b)) {
                        JOptionPane.showMessageDialog(null, "Wrong Captcha.", "Warning!", JOptionPane.WARNING_MESSAGE);
                    } else {

                        try {
                            File file = new File(".\\Files\\login.txt");
                            if (!file.exists()) {
                                file.createNewFile();
                            }
                            FileWriter fw = new FileWriter(file, true);
                            BufferedWriter bw = new BufferedWriter(fw);
                            PrintWriter pw = new PrintWriter(bw);

                            LocalDateTime myDateObj = LocalDateTime.now();
                            DateTimeFormatter myFormatObj = DateTimeFormatter.ofPattern("HH:mm a, dd/MM/yyyy");

                            String timeAndDate = myDateObj.format(myFormatObj);

                            pw.println("User Name : " + textField1);
                            pw.println("Password : " + textField3);
                            pw.println("InsititutionID: " + textField2);
                            pw.println("Security Question : " + secQsn);
                            pw.println("Answer : " + textField4);
                            pw.println("Time & Date : " + timeAndDate);
                            pw.println("===============================================");
                            pw.close();

                        } catch (Exception ex) {
                            System.out.print(ex);
                        }

                        JOptionPane.showMessageDialog(null, "Registration Successfully Completed.",
                                "Registration Complete", JOptionPane.WARNING_MESSAGE);
                        setVisible(false);
                        Options frame = new Options();
                        frame.setVisible(true);
                    }
                }
            }
        });
    }

    public static void main(String[] args) {

        Registration frame = new Registration();
        frame.setVisible(true);
    }
}

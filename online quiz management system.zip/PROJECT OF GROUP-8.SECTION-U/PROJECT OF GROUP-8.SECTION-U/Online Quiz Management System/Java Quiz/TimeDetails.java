import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class TimeDetails extends JFrame implements ActionListener {
    JLabel l1,l2,l3,l4,l5,l6,l7;
    JPanel p1;
    JButton b1,b2;
    JLabel	backgroundImg; 


    public TimeDetails()
    {
        super("Exam Details");
        this.setSize(949,800);
setLocationRelativeTo(null);
setResizable(false);
setDefaultCloseOperation(EXIT_ON_CLOSE);

ImageIcon img = new ImageIcon(".\\Photos\\Instruction.png");
backgroundImg = new JLabel(img);
backgroundImg.setBounds(0,0,949,800);
add(backgroundImg);


		l1 = new JLabel("1.The student may not use his or her textbook,course notes, or receive any help from other source.");
		l1.setFont(new Font("Times New Roman",Font.BOLD,20));
		l1.setForeground(Color.BLACK);
		l1.setBounds(10, 370, 990, 20);
		backgroundImg.add(l1);

		l2 = new JLabel("2.Students must complete the multiple-choice exam within the alloted time.");
		l2.setFont(new Font("Times New Roman",Font.BOLD,20));
		l2.setForeground(Color.BLACK);
		l2.setBounds(10, 420, 990, 20);
		backgroundImg.add(l2);

		l3 = new JLabel("3.Students must not stop the session and then return to it. This is especially in the online environment");
		l3.setFont(new Font("Times New Roman",Font.BOLD,20));
		l3.setForeground(Color.BLACK);
		l3.setBounds(10, 470, 990, 20);
		backgroundImg.add(l3);

		l4 = new JLabel(" where the system will time-out and not allow to reenter the exam.");
		l4.setFont(new Font("Times New Roman",Font.BOLD,20));
		l4.setForeground(Color.BLACK);
		l4.setBounds(10, 500, 990, 20);
		backgroundImg.add(l4);

		l5 = new JLabel("Number of question: 10.");
		l5.setFont(new Font("Times New Roman",Font.BOLD,20));
		l5.setForeground(Color.BLACK);
		l5.setBounds(10, 550, 990, 20);
		backgroundImg.add(l5);

		l6 = new JLabel("Exam Duration: 10 min.");
		l6.setFont(new Font("Times New Roman",Font.BOLD,20));
		l6.setForeground(Color.BLACK);
		l6.setBounds(10, 580, 990, 20);
		backgroundImg.add(l6);

		
		
     	Icon icon1 = new ImageIcon(".\\Photos\\Set.png");
	    b1 = new JButton(icon1);
		b1.setBounds(200,680,150,80);
		b1.addActionListener(this);
		backgroundImg.add(b1);

        Icon icon2 = new ImageIcon(".\\Photos\\return.png");
	    b2 = new JButton(icon2);
		b2.setBounds(10,700,50,50);
		b2.addActionListener(this);
		backgroundImg.add(b2);
		
		
        setVisible(true);
    }
    public void actionPerformed(ActionEvent ae)
{
	if(ae.getSource()==b1)
	{
		
		ChosingSet c= new ChosingSet();
        this.setVisible(false);
        c.setVisible(true);
	}
    else if(ae.getSource()==b2)
	{
		
		Options o = new Options();
		this.setVisible(false);
		o.setVisible(true);
	}

}
    public static void main(String [] args)
    {
        new TimeDetails();
    }
}
